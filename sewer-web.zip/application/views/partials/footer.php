<div class="spacer-100"></div>
</div> <!-- container ends -->

	<script type="text/javascript" src="<?=base_url()?>/js/jquery.validate.min.js""></script>
	

</body>
</html>
				
