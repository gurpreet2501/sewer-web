<ul class="nav navbar-nav">
    <li class="">
      <a href='<?php echo site_url('/dashboard/index')?>'>Dashboard</a> 
    </li>

    </ul>
